import { media, desvio } from "./stats.js";

console.log(media([1, 3, 5, 7, 9 ]));
console.log(desvio([1, 3, 5, 7, 9]));

